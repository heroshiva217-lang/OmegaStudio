# Omega Studio Android — v0.5.0 development build

Omega Studio is an Android video-editor prototype using AndroidX Media3 Transformer. This is a source project, not a tested release APK.

## Implemented in the current source
- Import multiple video clips and export them sequentially in the selected order.
- Reorder clips with Move Left / Move Right and remove clips from the timeline.
- Set trim-in and trim-out percentages for each selected clip.
- Native H.264/AAC MP4 export, progress reporting and cancellation.
- Brightness/contrast effects and sampled animated brightness/contrast keyframes.
- Burned-in title, animated title vertical position and time-ranged captions.
- Background music sequence mixed with source audio, with independent gain settings.
- Output profiles for 720p, 1080p, vertical and square, plus frame-rate cap and bitrate profiles.
- Rendered fade-to-black at clip edges. This is not a true crossfade between two simultaneous video streams.
- Project JSON save/load, captions/keyframe editing and snapshot undo/redo for supported controls.

## Not yet implemented / not equivalent to Premiere Pro
- Independent overlapping video tracks with arbitrary clip placement, nested compositions or picture-in-picture timeline compositing.
- True two-source crossfades, transition library, masks/chroma key, LUT management, motion tracking, waveform editing, audio automation, proxy media, advanced color grading, project interchange, and full professional codec controls.
- The playback-speed selector currently affects preview; native export speed processing is not yet wired end-to-end.
- Browser file-input fallback is preview-only; native export requires media selected through the Android Media button.

## APK status
This environment has Java but no Android SDK, Gradle installation/cache, and network DNS is unavailable, so I could not compile or validate an APK here. I have included a GitHub Actions workflow at `.github/workflows/android-apk.yml`; push this source project to a GitHub repository and run the **Build Omega Studio APK** workflow to compile the debug APK and download it from the workflow's Artifacts section. A CI build still needs compiler/test verification before installing on a real device.

## Local build
Open the folder in Android Studio, install Android SDK Platform 35 and a compatible Gradle/Android Gradle Plugin toolchain, sync, then run **Build > Build APK(s)**. Test exports with short clips first; codec behavior and max dimensions depend on device capabilities.

## Official API references
- https://developer.android.com/media/implement/editing-app
- https://developer.android.com/media/media3/transformer/composition
- https://developer.android.com/reference/androidx/media3/effect/CanvasOverlay
- https://developer.android.com/reference/androidx/media3/transformer/EditedMediaItem.Builder
- https://developer.android.com/reference/androidx/media3/transformer/EditedMediaItemSequence.Builder
