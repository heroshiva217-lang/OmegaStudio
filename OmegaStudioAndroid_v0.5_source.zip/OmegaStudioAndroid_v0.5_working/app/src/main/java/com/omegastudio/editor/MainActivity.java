package com.omegastudio.editor;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.media.MediaMetadataRetriever;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.Brightness;
import androidx.media3.effect.Contrast;
import androidx.media3.effect.CanvasOverlay;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.common.Effects;
import androidx.media3.common.audio.ChannelMixingAudioProcessor;
import androidx.media3.common.audio.ChannelMixingMatrix;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.VideoEncoderSettings;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

@UnstableApi
public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 2101;
    private static final int PICK_AUDIO = 2102;
    private android.webkit.ValueCallback<android.net.Uri[]> filePathCallback;
    private static final int PICK_WEB_FILE = 2103;
    private WebView webView;
    private Uri selectedUri;
    private final ArrayList<Uri> selectedUris = new ArrayList<>();
    private Uri musicUri;
    private Transformer activeTransformer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean exportInProgress = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(11, 14, 20));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(11, 14, 20));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = params.getAcceptTypes();
                String type = (types != null && types.length > 0 && types[0] != null && !types[0].isEmpty()) ? types[0] : "*/*";
                intent.setType(type);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try { startActivityForResult(intent, PICK_WEB_FILE); }
                catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new EditorBridge(), "OmegaNative");
        webView.loadUrl("file:///android_asset/editor.html");
    }

    private void js(String javascript) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(javascript, null);
        });
    }

    private class EditorBridge {
        @JavascriptInterface public void pickMedia() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("video/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_MEDIA);
            });
        }

        @JavascriptInterface public void pickAudio() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("audio/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_AUDIO);
            });
        }

        @JavascriptInterface public void export(String json) {
            runOnUiThread(() -> startExport(json));
        }

        @JavascriptInterface public void setClipOrder(String json) {
            runOnUiThread(() -> {
                try {
                    org.json.JSONArray order = new org.json.JSONArray(json);
                    ArrayList<Uri> reordered = new ArrayList<>();
                    for (int i = 0; i < order.length(); i++) {
                        Uri candidate = Uri.parse(order.optString(i, ""));
                        if (candidate != null && selectedUris.contains(candidate) && !reordered.contains(candidate)) reordered.add(candidate);
                    }
                    selectedUris.clear();
                    selectedUris.addAll(reordered);
                    selectedUri = selectedUris.isEmpty() ? null : selectedUris.get(0);
                    toast("Timeline order updated");
                } catch (Exception e) {
                    toast("Could not update clip order");
                }
            });
        }

        @JavascriptInterface public void clearAudio() { musicUri = null; }

        @JavascriptInterface public void cancelExport() {
            runOnUiThread(() -> {
                if (activeTransformer != null && exportInProgress) {
                    activeTransformer.cancel();
                    exportInProgress = false;
                    activeTransformer = null;
                    js("window.onNativeExportEvent && window.onNativeExportEvent('cancelled','Export cancelled')");
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_WEB_FILE) {
            if (filePathCallback != null) {
                Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        if ((requestCode == PICK_MEDIA || requestCode == PICK_AUDIO) && resultCode == RESULT_OK && data != null) {
            if (requestCode == PICK_AUDIO) {
                Uri uriValue = data.getData();
                if (uriValue == null) return;
                try { getContentResolver().takePersistableUriPermission(uriValue, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                musicUri = uriValue;
                String uri = JSONObject.quote(uriValue.toString());
                String name = JSONObject.quote(uriValue.getLastPathSegment() == null ? "Imported audio" : uriValue.getLastPathSegment());
                js("window.onNativeAudioPicked && window.onNativeAudioPicked(" + uri + "," + name + ")");
            } else {
                ArrayList<Uri> picked = new ArrayList<>();
                if (data.getClipData() != null) {
                    for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                        Uri u = data.getClipData().getItemAt(i).getUri();
                        if (u != null && !picked.contains(u)) picked.add(u);
                    }
                } else if (data.getData() != null) {
                    picked.add(data.getData());
                }
                if (picked.isEmpty()) return;
                selectedUris.clear();
                selectedUris.addAll(picked);
                selectedUri = selectedUris.get(0);
                org.json.JSONArray payload = new org.json.JSONArray();
                for (Uri u : selectedUris) {
                    try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                    String segment = u.getLastPathSegment();
                    JSONObject entry = new JSONObject();
                    try { entry.put("uri", u.toString()); entry.put("name", segment == null ? "Video clip" : segment); entry.put("durationMs", getDurationMs(u)); } catch (Exception ignored) { }
                    payload.put(entry);
                }
                js("window.onNativeMediaPickedList && window.onNativeMediaPickedList(" + JSONObject.quote(payload.toString()) + ")");
            }
        }
    }

    @OptIn(markerClass = UnstableApi.class)
    private void startExport(String json) {
        if (exportInProgress) { toast("An export is already running."); return; }
        if (selectedUris.isEmpty() && selectedUri != null) selectedUris.add(selectedUri);
        if (selectedUris.isEmpty()) {
            js("window.onNativeExportEvent && window.onNativeExportEvent('error','Import at least one video clip using the Media button first.')");
            return;
        }
        try {
            JSONObject options = new JSONObject(json);
            double defaultInRatio = clamp(options.optDouble("trimIn", 0), 0, 0.99);
            double defaultOutRatio = clamp(options.optDouble("trimOut", 1), defaultInRatio + 0.001, 1);
            org.json.JSONArray clipEdits = options.optJSONArray("clipEdits");
            org.json.JSONArray keyframes = options.optJSONArray("keyframes");
            if (keyframes == null) keyframes = new org.json.JSONArray();
            org.json.JSONArray captions = options.optJSONArray("captions");
            if (captions == null) captions = new org.json.JSONArray();
            List<EditedMediaItem> mainItems = new ArrayList<>();
            String resolution = options.optString("resolution", "source");
            String title = options.optString("title", "");
            boolean titleEnabled = options.optBoolean("titleEnabled", false);
            int titleSize = (int) clamp(options.optDouble("titleSize", 32), 16, 96);
            String titlePosition = options.optString("titlePos", "center");
            boolean muted = options.optBoolean("muted", false);
            float sourceGain = (float) clamp(options.optDouble("sourceVolume", 100) / 100.0, 0, 1.5);
            if (muted) sourceGain = 0f;
            int targetFps = parseFps(options.optString("fps", "source"));
            float transitionSeconds = (float) clamp(options.optDouble("transitionSeconds", 0.35), 0, 2.0);

            long globalTimelineMs = 0;
            for (int clipIndex = 0; clipIndex < selectedUris.size(); clipIndex++) {
                Uri uri = selectedUris.get(clipIndex);
                long sourceDurationMs = getDurationMs(uri);
                JSONObject clipEdit = clipEdits != null ? clipEdits.optJSONObject(clipIndex) : null;
                double clipInRatio = clamp(clipEdit != null ? clipEdit.optDouble("trimIn", clipIndex == 0 ? defaultInRatio : 0) : (clipIndex == 0 ? defaultInRatio : 0), 0, 0.99);
                double clipOutRatio = clamp(clipEdit != null ? clipEdit.optDouble("trimOut", clipIndex == 0 ? defaultOutRatio : 1) : (clipIndex == 0 ? defaultOutRatio : 1), clipInRatio + 0.001, 1);
                long trimStartMs = Math.max(0, Math.round(sourceDurationMs * clipInRatio));
                long trimEndMs = Math.min(sourceDurationMs, Math.max(trimStartMs + 100, Math.round(sourceDurationMs * clipOutRatio)));
                long clipDurationMs = trimEndMs - trimStartMs;
                if (clipDurationMs < 100) continue;

                // Split at keyframe boundaries and at 250 ms intervals while animated
                // color keyframes are active. Each segment is a real native render item.
                java.util.TreeSet<Long> boundaries = new java.util.TreeSet<>();
                boundaries.add(0L); boundaries.add(clipDurationMs);
                boolean animatedColor = hasKeyframeProperty(keyframes, "brightness") || hasKeyframeProperty(keyframes, "contrast");
                double colorStartSec = Double.POSITIVE_INFINITY, colorEndSec = Double.NEGATIVE_INFINITY;
                for (int k = 0; k < keyframes.length(); k++) {
                    JSONObject frame = keyframes.optJSONObject(k); if (frame == null) continue;
                    String property = frame.optString("property");
                    if ("brightness".equals(property) || "contrast".equals(property)) {
                        double t = frame.optDouble("time", -1);
                        if (t >= 0) { colorStartSec = Math.min(colorStartSec, t); colorEndSec = Math.max(colorEndSec, t); }
                    }
                }
                if (animatedColor && colorEndSec > colorStartSec) {
                    long localStart = Math.max(0, Math.min(clipDurationMs, Math.round((colorStartSec - globalTimelineMs / 1000.0) * 1000)));
                    long localEnd = Math.max(0, Math.min(clipDurationMs, Math.round((colorEndSec - globalTimelineMs / 1000.0) * 1000)));
                    boundaries.add(localStart); boundaries.add(localEnd);
                    long firstSample = ((localStart + 249) / 250) * 250;
                    for (long t = firstSample; t < localEnd; t += 250) boundaries.add(t);
                }
                for (int k = 0; k < keyframes.length(); k++) {
                    JSONObject frame = keyframes.optJSONObject(k); if (frame == null) continue;
                    double t = frame.optDouble("time", -1);
                    long local = Math.round((t - globalTimelineMs / 1000.0) * 1000.0);
                    if (local > 0 && local < clipDurationMs) boundaries.add(local);
                }
                List<Long> points = new ArrayList<>(boundaries);
                for (int seg = 0; seg < points.size() - 1; seg++) {
                    long segmentOffsetMs = points.get(seg);
                    long segmentEndMs = points.get(seg + 1);
                    if (segmentEndMs - segmentOffsetMs < 20) continue;
                    long segmentSourceStart = trimStartMs + segmentOffsetMs;
                    long segmentSourceEnd = trimStartMs + segmentEndMs;
                    long globalSegmentStartMs = globalTimelineMs + segmentOffsetMs;
                    double sampleTime = (globalTimelineMs + (segmentOffsetMs + segmentEndMs) / 2.0) / 1000.0;
                    double brightnessUi = animatedColor ? interpolateKeyframe(keyframes, "brightness", sampleTime, options.optDouble("brightness", 100)) : options.optDouble("brightness", 100);
                    double contrastUi = animatedColor ? interpolateKeyframe(keyframes, "contrast", sampleTime, options.optDouble("contrast", 100)) : options.optDouble("contrast", 100);
                    float brightness = (float) clamp((brightnessUi - 100.0) / 100.0, -1, 1);
                    float contrast = (float) clamp((contrastUi - 100.0) / 80.0, -1, 1);
                    List<androidx.media3.common.Effect> videoEffects = new ArrayList<>();
                    if (Math.abs(brightness) > 0.005f) videoEffects.add(new Brightness(brightness));
                    if (Math.abs(contrast) > 0.005f) videoEffects.add(new Contrast(contrast));
                    if ("720".equals(resolution)) videoEffects.add(Presentation.createForWidthAndHeight(1280, 720, Presentation.LAYOUT_SCALE_TO_FIT));
                    else if ("1080".equals(resolution)) videoEffects.add(Presentation.createForWidthAndHeight(1920, 1080, Presentation.LAYOUT_SCALE_TO_FIT));
                    else if ("vertical".equals(resolution)) videoEffects.add(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT));
                    else if ("square".equals(resolution)) videoEffects.add(Presentation.createForWidthAndHeight(1080, 1080, Presentation.LAYOUT_SCALE_TO_FIT));

                    List<TextureOverlay> overlays = new ArrayList<>();
                    if ((titleEnabled && !title.trim().isEmpty()) || captions.length() > 0 || hasKeyframeProperty(keyframes, "titleY")) {
                        overlays.add(new ProjectTextOverlay(titleEnabled ? title : "", titleSize, titlePosition, captions, keyframes, globalSegmentStartMs));
                    }
                    if (transitionSeconds > 0.01f && selectedUris.size() > 1) {
                        overlays.add(new FadeOverlay(segmentOffsetMs, clipDurationMs, Math.round(transitionSeconds * 1000)));
                    }
                    if (!overlays.isEmpty()) videoEffects.add(new OverlayEffect(overlays));

                    MediaItem mediaItem = new MediaItem.Builder().setUri(uri)
                            .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                                    .setStartPositionMs(segmentSourceStart).setEndPositionMs(segmentSourceEnd).build()).build();
                    List<androidx.media3.common.audio.AudioProcessor> sourceAudio = new ArrayList<>();
                    if (Math.abs(sourceGain - 1f) > 0.001f) sourceAudio.add(volumeProcessor(sourceGain));
                    EditedMediaItem.Builder editedBuilder = new EditedMediaItem.Builder(mediaItem)
                            .setEffects(new Effects(sourceAudio, videoEffects));
                    if (targetFps > 0) editedBuilder.setFrameRate(targetFps);
                    EditedMediaItem edited = editedBuilder.build();
                    if (muted) {
                        EditedMediaItem.Builder silentBuilder = new EditedMediaItem.Builder(mediaItem).setRemoveAudio(true).setEffects(new Effects(Collections.emptyList(), videoEffects));
                        if (targetFps > 0) silentBuilder.setFrameRate(targetFps);
                        mainItems.add(silentBuilder.build());
                    } else mainItems.add(edited);
                }
                globalTimelineMs += clipDurationMs;
            }
            if (mainItems.isEmpty()) throw new IllegalArgumentException("No renderable clip segments were created.");
            EditedMediaItemSequence mainSequence = muted
                    ? EditedMediaItemSequence.withVideoFrom(mainItems)
                    : EditedMediaItemSequence.withAudioAndVideoFrom(mainItems);
            Composition composition;
            float musicGain = (float) clamp(options.optDouble("musicVolume", 80) / 100.0, 0, 1.5);
            if (musicUri != null && musicGain > 0.001f) {
                List<androidx.media3.common.audio.AudioProcessor> musicProcessors = new ArrayList<>();
                if (Math.abs(musicGain - 1f) > 0.001f) musicProcessors.add(volumeProcessor(musicGain));
                EditedMediaItem musicItem = new EditedMediaItem.Builder(MediaItem.fromUri(musicUri))
                        .setEffects(new Effects(musicProcessors, Collections.emptyList())).build();
                EditedMediaItemSequence musicSequence = EditedMediaItemSequence.withAudioFrom(Collections.singletonList(musicItem))
                        .buildUpon().setIsLooping(true).build();
                composition = new Composition.Builder(mainSequence, musicSequence).build();
            } else {
                composition = new Composition.Builder(mainSequence).build();
            }

            int bitrate = selectBitrate(options.optString("quality", "standard"), resolution, targetFps);
            DefaultEncoderFactory encoderFactory = new DefaultEncoderFactory.Builder(getApplicationContext())
                    .setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                    .setEnableFallback(true).build();
            File movies = new File(getExternalFilesDir(null), "OmegaStudioExports");
            if (!movies.exists() && !movies.mkdirs()) throw new IllegalStateException("Cannot create export folder.");
            String outputName = "OmegaStudio_" + System.currentTimeMillis() + ".mp4";
            File output = new File(movies, outputName);
            activeTransformer = new Transformer.Builder(this)
                    .setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setEncoderFactory(encoderFactory)
                    .addListener(new Transformer.Listener() {
                        @Override public void onCompleted(Composition c, ExportResult result) {
                            exportInProgress = false; activeTransformer = null;
                            js("window.onNativeExportEvent && window.onNativeExportEvent('complete'," + JSONObject.quote(output.getAbsolutePath()) + ")");
                            toast("Export complete");
                        }
                        @Override public void onError(Composition c, ExportResult result, ExportException exception) {
                            exportInProgress = false; activeTransformer = null;
                            if (output.exists()) output.delete();
                            String message = exception.getMessage() == null ? "Media export failed on this device." : exception.getMessage();
                            js("window.onNativeExportEvent && window.onNativeExportEvent('error'," + JSONObject.quote(message) + ")");
                        }
                    }).build();
            exportInProgress = true;
            String details = "Rendering " + selectedUris.size() + " sequential clip(s), " + (transitionSeconds > 0.01f ? "fade-to-black cuts, " : "hard cuts, ") + (hasKeyframeProperty(keyframes, "brightness") || hasKeyframeProperty(keyframes, "contrast") || hasKeyframeProperty(keyframes, "titleY") ? "animated keyframes, " : "") + "burned title/captions, " + (musicUri != null ? "music mix, " : "") + resolution + ", " + (targetFps > 0 ? targetFps + " fps cap" : "source fps") + ", " + (bitrate / 1000000f) + " Mbps…";
            js("window.onNativeExportEvent && window.onNativeExportEvent('started'," + JSONObject.quote(details) + ")");
            activeTransformer.start(composition, output.getAbsolutePath());
            pollProgress();
        } catch (Exception e) {
            exportInProgress = false;
            js("window.onNativeExportEvent && window.onNativeExportEvent('error'," + JSONObject.quote(e.getMessage() == null ? "Could not start export." : e.getMessage()) + ")");
        }
    }

    private long getDurationMs(Uri uri) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this, uri);
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long result = duration == null ? 0 : Long.parseLong(duration);
            if (result <= 0) throw new IllegalArgumentException("Could not read duration for " + uri.getLastPathSegment());
            return result;
        } finally { try { retriever.release(); } catch (Exception ignored) { } }
    }

    private static int parseFps(String value) {
        try { int fps = Integer.parseInt(value); return fps == 24 || fps == 25 || fps == 30 || fps == 60 ? fps : 0; }
        catch (Exception ignored) { return 0; }
    }

    private static int selectBitrate(String quality, String resolution, int fps) {
        int pixels = "720".equals(resolution) ? 1280 * 720 : ("vertical".equals(resolution) ? 1080 * 1920 : ("square".equals(resolution) ? 1080 * 1080 : 1920 * 1080));
        double base = pixels <= 1280 * 720 ? 4_000_000 : 8_000_000;
        if ("high".equals(quality)) base *= 1.5;
        else if ("max".equals(quality)) base *= 2.25;
        if (fps >= 50) base *= 1.5; else if (fps >= 24 && fps <= 25) base *= 0.85;
        return (int) Math.min(40_000_000, Math.max(2_000_000, base));
    }

    private static boolean hasKeyframeProperty(org.json.JSONArray frames, String property) {
        for (int i = 0; i < frames.length(); i++) { JSONObject k = frames.optJSONObject(i); if (k != null && property.equals(k.optString("property"))) return true; }
        return false;
    }

    private static double interpolateKeyframe(org.json.JSONArray frames, String property, double time, double fallback) {
        List<JSONObject> keys = new ArrayList<>();
        for (int i = 0; i < frames.length(); i++) { JSONObject k = frames.optJSONObject(i); if (k != null && property.equals(k.optString("property"))) keys.add(k); }
        Collections.sort(keys, (a, b) -> Double.compare(a.optDouble("time", 0), b.optDouble("time", 0)));
        if (keys.isEmpty()) return fallback;
        JSONObject first = keys.get(0), last = keys.get(keys.size() - 1);
        if (time <= first.optDouble("time", 0)) return first.optDouble("value", fallback);
        if (time >= last.optDouble("time", 0)) return last.optDouble("value", fallback);
        for (int i = 1; i < keys.size(); i++) {
            JSONObject a = keys.get(i - 1), b = keys.get(i);
            double ta = a.optDouble("time", 0), tb = b.optDouble("time", 0);
            if (time <= tb) { double f = (time - ta) / Math.max(0.001, tb - ta); return a.optDouble("value", fallback) + (b.optDouble("value", fallback) - a.optDouble("value", fallback)) * f; }
        }
        return fallback;
    }

    @OptIn(markerClass = UnstableApi.class)
    private static ChannelMixingAudioProcessor volumeProcessor(float gain) {
        ChannelMixingAudioProcessor processor = new ChannelMixingAudioProcessor();
        // Keep each channel independent while applying the requested gain. Register common
        // channel counts so surround-source media does not fail merely because a gain is set.
        for (int channels = 1; channels <= 8; channels++) {
            float[] coefficients = new float[channels * channels];
            for (int c = 0; c < channels; c++) coefficients[c * channels + c] = gain;
            processor.putChannelMixingMatrix(new ChannelMixingMatrix(channels, channels, coefficients));
        }
        return processor;
    }

    @UnstableApi
    private static final class ProjectTextOverlay extends CanvasOverlay {
        private final String title;
        private final int titleSize;
        private final String titlePosition;
        private final org.json.JSONArray captions;
        private final org.json.JSONArray keyframes;
        private final long timelineOffsetMs;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        ProjectTextOverlay(String title, int titleSize, String titlePosition, org.json.JSONArray captions, org.json.JSONArray keyframes, long timelineOffsetMs) {
            super(true);
            this.title = title; this.titleSize = titleSize; this.titlePosition = titlePosition;
            this.captions = captions == null ? new org.json.JSONArray() : captions;
            this.keyframes = keyframes == null ? new org.json.JSONArray() : keyframes;
            this.timelineOffsetMs = timelineOffsetMs;
        }
        @Override public void onDraw(Canvas canvas, long presentationTimeUs) {
            float w = canvas.getWidth(), h = canvas.getHeight();
            paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            paint.setTextAlign(Paint.Align.CENTER); paint.setColor(Color.WHITE);
            paint.setTextSize(Math.max(titleSize, w * titleSize / 1080f));
            paint.setShadowLayer(Math.max(3f, w / 360f), 0f, 2f, Color.BLACK);
            long tMs = presentationTimeUs / 1000L + timelineOffsetMs;
            if (!title.isEmpty()) {
                float y = "top".equals(titlePosition) ? h * 0.13f : ("bottom".equals(titlePosition) ? h * 0.88f : h * 0.52f);
                double animatedY = interpolateKeyframe(keyframes, "titleY", tMs / 1000.0, -1);
                if (animatedY >= 0) y = (float) (h * clamp(animatedY, 5, 95) / 100.0);
                canvas.drawText(title, w / 2f, y, paint);
            }
            for (int i = 0; i < captions.length(); i++) {
                JSONObject c = captions.optJSONObject(i); if (c == null) continue;
                long start = (long) (c.optDouble("start", 0) * 1000);
                long end = (long) (c.optDouble("end", 0) * 1000);
                if (tMs >= start && tMs <= end) {
                    paint.setTextSize(Math.max(22f, w * 0.035f));
                    String caption = c.optString("text", "");
                    drawWrappedText(canvas, caption, w * 0.9f, h * 0.90f, paint);
                }
            }
            paint.clearShadowLayer();
        }
        private void drawWrappedText(Canvas canvas, String text, float maxWidth, float y, Paint p) {
            if (p.measureText(text) <= maxWidth) { canvas.drawText(text, canvas.getWidth() / 2f, y, p); return; }
            StringBuilder line = new StringBuilder();
            String[] words = text.split("\\s+");
            List<String> lines = new ArrayList<>();
            for (String word : words) {
                String candidate = line.length() == 0 ? word : line + " " + word;
                if (p.measureText(candidate) > maxWidth && line.length() > 0) { lines.add(line.toString()); line = new StringBuilder(word); }
                else line = new StringBuilder(candidate);
            }
            if (line.length() > 0) lines.add(line.toString());
            float lineY = y - (lines.size() - 1) * p.getTextSize() * 0.55f;
            for (String row : lines) { canvas.drawText(row, canvas.getWidth() / 2f, lineY, p); lineY += p.getTextSize() * 1.1f; }
        }
    }

    @UnstableApi
    private static final class FadeOverlay extends CanvasOverlay {
        private final long segmentOffsetMs, clipDurationMs, fadeDurationMs;
        private final Paint fadePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        FadeOverlay(long segmentOffsetMs, long clipDurationMs, long fadeDurationMs) {
            super(true); this.segmentOffsetMs = segmentOffsetMs; this.clipDurationMs = clipDurationMs; this.fadeDurationMs = Math.max(1, fadeDurationMs);
        }
        @Override public void onDraw(Canvas canvas, long presentationTimeUs) {
            long clipTimeMs = segmentOffsetMs + presentationTimeUs / 1000L;
            double fadeIn = clipTimeMs < fadeDurationMs ? 1.0 - clipTimeMs / (double) fadeDurationMs : 0.0;
            long remaining = clipDurationMs - clipTimeMs;
            double fadeOut = remaining < fadeDurationMs ? 1.0 - Math.max(0, remaining) / (double) fadeDurationMs : 0.0;
            int alpha = (int) (255 * clamp(Math.max(fadeIn, fadeOut), 0, 1));
            if (alpha > 0) { fadePaint.setColor(Color.BLACK); fadePaint.setAlpha(alpha); canvas.drawRect(0, 0, canvas.getWidth(), canvas.getHeight(), fadePaint); }
        }
    }

    private void pollProgress() {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!exportInProgress || activeTransformer == null) return;
                try {
                    ProgressHolder holder = new ProgressHolder();
                    int state = activeTransformer.getProgress(holder);
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        js("window.onNativeExportEvent && window.onNativeExportEvent('progress'," + holder.progress + ")");
                    }
                } catch (Exception ignored) { }
                if (exportInProgress) handler.postDelayed(this, 450);
            }
        }, 450);
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
    }

    @Override public void onBackPressed() {
        if (exportInProgress) {
            toast("Export is running. Cancel it from the editor first.");
        } else if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
